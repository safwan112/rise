SpatieFlareClientFlare;

$flare = Flare::make('7PGM6DkkCj6njuCyCcj7jxl4RZxBcd9n')->registerFlareHandlers();